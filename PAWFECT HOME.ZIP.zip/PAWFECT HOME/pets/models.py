from django.db import models
from django.contrib.auth.models import User

class Pet(models.Model):
    name = models.CharField(max_length=50)
    age = models.IntegerField()
    type = models.CharField(max_length=50)  # Dog, Cat, etc.
    image = models.ImageField(upload_to='pets/')
    description = models.TextField()
    available = models.BooleanField(default=True)

    def __str__(self):
        return self.name

class Adoption(models.Model):
    pet = models.ForeignKey(Pet, on_delete=models.CASCADE)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    adopted_on = models.DateTimeField(auto_now_add=True)

class Contact(models.Model):
    name = models.CharField(max_length=50)
    email = models.EmailField()
    message = models.TextField()
    sent_on = models.DateTimeField(auto_now_add=True)

