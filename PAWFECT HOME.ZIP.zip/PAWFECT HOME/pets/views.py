from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from .models import Pet, Adoption, Contact
from django.contrib import messages
from django.contrib.auth.decorators import login_required

@login_required
def add_pet(request):
    if request.method == 'POST' and request.FILES['image']:
        name = request.POST['name']
        age = request.POST['age']
        type = request.POST['type']
        description = request.POST['description']
        image = request.FILES['image']
        Pet.objects.create(name=name, age=age, type=type, description=description, image=image)
        messages.success(request, 'Pet added successfully!')
        return redirect('pet_list')
    return render(request, 'add_pet.html')

@login_required
def pet_list(request):
    pets = Pet.objects.all()
    return render(request, 'pet_list.html', {'pets': pets})

@login_required
def adopt_pet(request):
    if request.method == "POST":
        # handle form data
        name = request.POST.get("name")
        email = request.POST.get("email")
        phone = request.POST.get("phone")
        pet_type = request.POST.get("pet_type")
        reason = request.POST.get("reason")
        # save to DB or send email here
    return render(request, "adopt_pet.html")




# Home page
def home(request):
    pets = Pet.objects.filter(available=True)
    return render(request, 'home.html', {'pets': pets})

def about(request):
    return render(request, 'about.html')

def faq(request):
    return render(request, 'faq.html')

def contact(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        message = request.POST['message']
        Contact.objects.create(name=name, email=email, message=message)
        messages.success(request, 'Message sent successfully!')
    return render(request, 'contact.html')

def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        User.objects.create_user(username=username, password=password)
        messages.success(request, 'Account created! Please login.')
        return redirect('login')
    return render(request, 'register.html')

def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return redirect('home')
        else:
            messages.error(request, 'Invalid credentials')
    return render(request, 'login.html')

def user_logout(request):
    logout(request)
    return redirect('home')

