from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('about/', views.about, name='about'),
    path('faq/', views.faq, name='faq'),
    path('contact/', views.contact, name='contact'),
    path('register/', views.register, name='register'),
    path('login/', views.user_login, name='login'),
    path('logout/', views.user_logout, name='logout'),
    path('pet-list/', views.pet_list, name='pet_list'),
    path('add-pet/', views.add_pet, name='add_pet'),
    path('adopt/', views.adopt_pet, name='adopt'),

    path('adopt/<int:pet_id>/', views.adopt_pet, name='adopt_pet'),
]
